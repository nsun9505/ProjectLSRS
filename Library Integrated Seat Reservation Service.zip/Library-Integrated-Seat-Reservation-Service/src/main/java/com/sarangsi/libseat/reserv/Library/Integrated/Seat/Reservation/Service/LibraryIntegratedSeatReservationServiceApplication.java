package com.sarangsi.libseat.reserv.Library.Integrated.Seat.Reservation.Service;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LibraryIntegratedSeatReservationServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(LibraryIntegratedSeatReservationServiceApplication.class, args);
	}

}
