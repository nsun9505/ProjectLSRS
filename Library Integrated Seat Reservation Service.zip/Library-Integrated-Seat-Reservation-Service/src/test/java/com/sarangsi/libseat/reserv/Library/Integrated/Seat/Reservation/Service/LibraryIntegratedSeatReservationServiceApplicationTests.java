package com.sarangsi.libseat.reserv.Library.Integrated.Seat.Reservation.Service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LibraryIntegratedSeatReservationServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
